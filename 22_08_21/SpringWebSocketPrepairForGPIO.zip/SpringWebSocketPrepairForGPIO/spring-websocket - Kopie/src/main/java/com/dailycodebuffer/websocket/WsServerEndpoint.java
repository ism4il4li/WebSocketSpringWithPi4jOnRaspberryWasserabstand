package com.dailycodebuffer.websocket;

import org.springframework.stereotype.Component;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;

@Component
@ServerEndpoint("/myWs")
public class WsServerEndpoint {
	
    @OnOpen
    public void onOpen(Session session) {
        System.out.println("Successful connection");
    }

    @OnClose
    public void onClose(Session session) {
        System.out.println("Connection closure");
    }


   @OnMessage
   public String gerade(String text, Session session) throws InterruptedException, IOException {
	   for(int i = 0; i<20;i++) {
		   
		   if(i%2!=0) {
			   Thread.sleep(1000);
			   session.getBasicRemote().sendText("<h1>das ist mein H1 bei LED an</h1>");
			   }
		   else {
			   Thread.sleep(1000);
			   session.getBasicRemote().sendText("<h2>das ist mein H2 bei LED aus</h2>");
			   }
		   
	   }return "Ende";
   }

}
